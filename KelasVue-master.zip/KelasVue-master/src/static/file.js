export default {
    arrayProduk: [
        { nama: 'Buku', harga: 5000, kualitas: 100 },
        { nama: 'Bolpoin', harga: 6000, kualitas: 70},
        { nama: 'Pensil', harga: 3000, kualitas: 70},
        { nama: 'Penggaris', harga: 7000, kualitas: 70},
        { nama: 'Penghapus', harga: 4000, kualitas: 70},
        { nama: 'Papan Tulis', harga: 60000, kualitas: 70},
    ],
}