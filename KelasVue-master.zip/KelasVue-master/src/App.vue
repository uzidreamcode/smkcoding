<template>
  <div id="nav">
    
    <router-link to="/">Home | </router-link>

    <router-link to="/about/book">About Book | </router-link>
    <router-link to="/about/ruler">About Ruler | </router-link>
    <router-link to="/about/eraser">About Eraser</router-link>

  </div>

  <router-view />

</template>

<script>
export default {
  name: 'App',
  data() {
    return {
    }
  }
}
</script>

<style>

</style>